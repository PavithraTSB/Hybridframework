package flipkart_hybrid_FunctionLibaries;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;



import flipkart_test.DriverScript;

public class LoginUI extends DriverScript{

	public static void preRequesties(int datarow) throws Exception {
		try {
			System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver.exe");
			driver=new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.get(testresults.getCellData(1, "Login", 0));
			Thread.sleep(3000);
		} catch (Exception e) {
			System.out.println("Login is not Successfull"+e.getMessage());
			throw new Exception(e);

		}

	}

	public static void loginFlipkart(int datarow) throws Exception {

		try {
			
			Thread.sleep(5000);
			driver.findElement(By.xpath("(//input[@type='text'])[2]")).sendKeys(testresults.getCellData(1, "Login", 1));
			driver.findElement(By.xpath("//input[@type='password']")).sendKeys(testresults.getCellData(1, "Login", 2));
			driver.findElement(By.xpath("(//button[@type='submit'])[2]")).click();

//			FKPageObjects.fKPage.userName.sendKeys(testresults.getCellData(1, "Login", 1));
//			FKPageObjects.fKPage.password.sendKeys(testresults.getCellData(1, "Login", 2)); 
//			FKPageObjects.fKPage.loginButton.click();
			Thread.sleep(3000);

		} catch (Exception e) {
			System.out.println("Login is not Successfull"+e.getMessage());
			throw new Exception(e);

		}


	}

	public static void logoutFlipKart() throws Exception {

		try {
			Actions builder=new Actions(driver);
			builder.moveToElement(driver.findElement(By.xpath("//div[text()='My Account']"))).build().perform();
			driver.findElement(By.xpath("//div[text()='Logout']")).click();

		} catch (Exception e) {
			System.out.println("Logout is not Successfull"+e.getMessage());
			throw new Exception(e);


		}


	}
	
}
