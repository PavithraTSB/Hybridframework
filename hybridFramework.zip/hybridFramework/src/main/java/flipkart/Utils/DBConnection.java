package flipkart.Utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import flipkart_test.DriverScript;

public class DBConnection extends DriverScript{


	public static void sqlquery(int datarow) throws Exception {

		try {

			String insertQuery="";
			String itemType="";
			String itemName="";
			String ItemPrice="";
			
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			String db_url= "jdbc:sqlserver://den1.mssql7.gear.host:1433;username=mss1;password=Mysql@1927;integratedsecurity=false;database=mss1";
			Connection con=DriverManager.getConnection(db_url);
			System.out.println("DB Connected");
			Statement st =con.createStatement();
			

//			ResultSetMetaData rsmd=rs.getMetaData();
//			//int colNum=rsmd.getColumnCount();
//			while(rs.next()) {

				for (Entry <String,String>eachValue : fetchMapData.entrySet()) {
					if(eachValue.getKey().equalsIgnoreCase("ItemType")){
					 itemType=eachValue.getValue();
						System.out.println("ItemType ="+itemType);
					}
					else if(eachValue.getKey().equalsIgnoreCase("ItemName")) {
						 itemName=eachValue.getValue();
						System.out.println("ItemName="+itemName);
					}
					else if(eachValue.getKey().equalsIgnoreCase("ItemPrice")) {
						ItemPrice=eachValue.getValue();
						System.out.println("ItemPrice ="+ItemPrice);			

					}
				}
				
				
				//insert into flipkart(DataRow,Item_Type,Item_Name,Item_Price) values ('12','itemtype','itemname','1000');
			
			String executeIdentitySet="SET IDENTITY_INSERT flipkart ON";
			insertQuery="Insert into flipkart(DataRow,Item_Type,Item_Name,Item_Price) values('" +datarow+ "'," +"'"+itemType+"',"+"'"+itemName+"',"+"'"+ItemPrice+"')";
			System.out.println(insertQuery);
			st.executeUpdate(executeIdentitySet);
			//st.executeQuery(executeIdentitySet);
			st.executeUpdate(insertQuery);
			System.out.println("Successfully Inserted");
			
			ResultSet rs=st.executeQuery("select * from flipkart");
			ResultSetMetaData rsmd=rs.getMetaData();
            int colNum=rsmd.getColumnCount();
            String dbTable;
            List<String>ls=new ArrayList();
			while(rs.next()) {
				for(int i=2;i<colNum;i++) {
					 dbTable=rs.getString(i);
					 ls.add(dbTable);
				}
				
			}
			System.out.println("Final Flipkart table"+ls);
			con.close();

		}catch (Exception e) {
			throw new Exception(e);
		}







	}

}
