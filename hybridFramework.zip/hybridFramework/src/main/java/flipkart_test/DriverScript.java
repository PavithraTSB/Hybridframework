package flipkart_test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import flipkart.Utils.DBConnection;
import flipkart_Excel_utils.TestResults;
import flipkart_hybrid_FunctionLibaries.FlipkartCategories;
import flipkart_hybrid_FunctionLibaries.LoginUI;

public class DriverScript {
	public static WebDriver driver = null;
	public static TestResults testresults=new TestResults();
	public static Properties prop=null;
	public static LinkedHashMap<String,String>fetchMapData=new LinkedHashMap();

	@BeforeSuite
	public void initialize() throws Exception {

		//		prop=new Properties();
		//		prop.load(new FileInputStream(new File("./src/test/resources/Config/object.properties")));
		System.out.println("Browser Intialization");

	}


	@Test
	@Parameters({"datarow"})
	public void getTestCases(int datarow) throws Exception {


		try {
			LoginUI.preRequesties(1);
			System.out.println("Going to Login" +datarow);
			LoginUI.loginFlipkart(1);
			fetchMapData=FlipkartCategories.materialSelection(fetchMapData, datarow);
			LoginUI.logoutFlipKart();
			DBConnection.sqlquery(datarow);


		} catch (Exception e) {
			throw new Exception(e);
		}
	}

	@AfterSuite
	public void quitBrowser() throws Exception {


		driver.quit();


	}
}
