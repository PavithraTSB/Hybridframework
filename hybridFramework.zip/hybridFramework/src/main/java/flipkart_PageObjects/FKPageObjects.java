package flipkart_PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import flipkart_test.DriverScript;

public class FKPageObjects extends DriverScript {

	public static Fkpage fKPage=new Fkpage(null);

	public static class Fkpage{
		public WebElement userName;
		public WebElement password;
		public WebElement loginButton;
		
		




		public Fkpage(By by) {

			userName=driver.findElement(By.xpath(DriverScript.prop.getProperty("userName")));
			password=driver.findElement(By.xpath(DriverScript.prop.getProperty("password")));
			loginButton=driver.findElement(By.xpath(DriverScript.prop.getProperty("loginButton")));
			
			
		}

	}



}
