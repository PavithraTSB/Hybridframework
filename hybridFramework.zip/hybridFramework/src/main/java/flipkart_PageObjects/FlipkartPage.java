package flipkart_PageObjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import flipkart_test.DriverScript;


public class FlipkartPage extends DriverScript{

	@FindBy(how=How.XPATH,using=("(//input[@type='text'])[2]"))WebElement username;
	WebDriver driver;


	public FlipkartPage(WebDriver driver) {
		this.driver=driver;
	   PageFactory.initElements(driver, this);
	}
	
	  public FlipkartPage sendUname(String email) throws IOException
	  { 
		  username.sendKeys(email);
		  return this;
	  
	  }
	 
	
	



}
