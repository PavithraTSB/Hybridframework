package flipkart_Excel_utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class TestResults {

	File file=null;
	public static FileInputStream fi=null;
	public static XSSFWorkbook wb=null;
	public static XSSFSheet sh=null;
	public static String data=null;
	public static XSSFRow row=null;
	public static XSSFCell cell=null;
	XSSFCellStyle style=null;
	XSSFCellStyle style1;
	XSSFFont font;
	XSSFFont font1;

	public String getCellData(int datarow,String sheetName,int index) throws IOException {

		try {
			String filename="Testdata.xlsx";
			file=new File(System.getProperty("user.dir")+"/src/test/resources/Testdata/"+filename);
			fi=new FileInputStream(file);
			wb=new XSSFWorkbook(fi);
			sh=wb.getSheet(sheetName);
			data=sh.getRow(datarow).getCell(index).toString();

		} catch (Exception e) {

			e.printStackTrace();
		}
		return data;


	}
	public void writeDataExcel(LinkedHashMap<String,String>map,int datarow) throws IOException {
		int cellNum=1;
		int rowNum=datarow;
		int j=0;
		String filename="Output.xlsx";
		try {

			file=new File(System.getProperty("user.dir")+"/src/test/resources/Testdata/"+filename);
		    wb=new XSSFWorkbook();
		    

			sh=wb.getSheet("Output_Data");
			// create font
			font= wb.createFont();
			font.setFontHeightInPoints((short)12);
			font.setFontName("Arial");
			font.setColor(IndexedColors.RED.getIndex());
			font.setItalic(false);

			style=wb.createCellStyle();
			style.setBorderBottom(BorderStyle.THIN);
			style.setBorderLeft(BorderStyle.THIN);
			style.setBorderRight(BorderStyle.THIN);
			style.setBorderTop(BorderStyle.THIN);
			style.setFont(font);

			font1= wb.createFont();
			font1.setFontHeightInPoints((short)10);
			font1.setFontName("Arial");
			font1.setItalic(false);

			style1=wb.createCellStyle();
			style1.setBorderBottom(BorderStyle.THIN);
			style1.setBorderLeft(BorderStyle.THIN);
			style1.setBorderRight(BorderStyle.THIN);
			style1.setBorderTop(BorderStyle.THIN);
			style1.setFont(font1);

			row=sh.createRow(0);

			cell=row.createCell(0);
			cell.setCellValue("DataRow");
			cell.setCellStyle(style);

			cell=row.createCell(1);
			cell.setCellValue("Item Type");
			cell.setCellStyle(style);
			cell=row.createCell(2);
			cell.setCellValue("Item Name");
			cell.setCellStyle(style);
			cell=row.createCell(3);
			cell.setCellValue("Item Price");
			cell.setCellStyle(style);

			Set<String>keySet=map.keySet();
			for (String key : keySet) {

				List<String>values=new ArrayList();
				values.add(map.get(key));


				if(sh.getRow(rowNum)==null) {
					row=sh.createRow(rowNum);
				}
				else {
					row.setRowNum(rowNum);
				}
				if(row.getCell(0)==null) {
					cell=row.createCell(0);
					cell.setCellValue(datarow);
					cell.setCellStyle(style1);
				}

				cell=row.createCell(cellNum);
				cell.setCellValue(values.get(j));
				cell.setCellStyle(style1);
				cellNum++;
			}
			rowNum++;

			FileOutputStream fos=new FileOutputStream(file);
			wb.write(fos);
			fos.close();
		} catch (Exception e) {
			System.out.println("Write data is not Successfull"+e.getMessage());
			e.printStackTrace();
		}

	}


}

